var searchData=
[
  ['vacia',['vacia',['../class_pila.html#a8422abd8aa4d73d13d1b7dfad8244bfd',1,'Pila']]],
  ['votosdepartamentosexo',['votosDepartamentoSexo',['../classdepartamento.html#a3fbf504b84d54e7a5881d52b5dbf80d5',1,'departamento']]]
];
