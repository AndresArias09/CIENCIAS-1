var searchData=
[
  ['x',['x',['../structx.html',1,'']]],
  ['x_3c_20candidate_20_3e',['x&lt; candidate &gt;',['../structx.html',1,'']]],
  ['x_3c_20city_20_3e',['x&lt; city &gt;',['../structx.html',1,'']]],
  ['x_3c_20departament_20_3e',['x&lt; departament &gt;',['../structx.html',1,'']]],
  ['x_3c_20departamentosimulacion_20_3e',['x&lt; departamentoSimulacion &gt;',['../structx.html',1,'']]],
  ['x_3c_20partid_20_3e',['x&lt; partid &gt;',['../structx.html',1,'']]],
  ['x_3c_20territoriosimulacion_20_3e',['x&lt; territorioSimulacion &gt;',['../structx.html',1,'']]]
];
