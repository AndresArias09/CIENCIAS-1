var searchData=
[
  ['sacar',['sacar',['../class_pila.html#acde306047acf91a183c42c9131bb969d',1,'Pila']]],
  ['simulacion',['simulacion',['../main_8cpp.html#a26a18788dc3baff7751efc5cc34345e9',1,'main.cpp']]]
];
