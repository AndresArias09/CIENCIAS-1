var searchData=
[
  ['sacar',['sacar',['../class_pila.html#acde306047acf91a183c42c9131bb969d',1,'Pila']]],
  ['sexo',['sexo',['../structcandidate.html#a9246a0984ff32e598f6da56d212b7a89',1,'candidate']]],
  ['sig',['sig',['../structnodo.html#add3a68f9ec1125a7ac8cc52693a3ab8c',1,'nodo::sig()'],['../structnode.html#ad409f80a1170f2f099b07cb7e2f4c8e4',1,'node::sig()']]],
  ['simulacion',['simulacion',['../main_8cpp.html#a26a18788dc3baff7751efc5cc34345e9',1,'main.cpp']]],
  ['simulacionciudades',['simulacionCiudades',['../classsimulacion_ciudades.html',1,'']]],
  ['simulacionciudades_2eh',['simulacionCiudades.h',['../simulacion_ciudades_8h.html',1,'']]],
  ['simulacionnacionales',['simulacionNacionales',['../structsimulacion_nacionales.html',1,'']]]
];
