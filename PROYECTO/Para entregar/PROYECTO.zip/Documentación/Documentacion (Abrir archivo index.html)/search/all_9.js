var searchData=
[
  ['node',['node',['../structnode.html',1,'']]],
  ['node_3c_20candidatosimulacion_20_3e',['node&lt; candidatoSimulacion &gt;',['../structnode.html',1,'']]],
  ['nodo',['nodo',['../structnodo.html',1,'']]],
  ['nodo_3c_20candidate_20_2a_3e',['nodo&lt; candidate *&gt;',['../structnodo.html',1,'']]],
  ['nodo_3c_20city_20_2a_3e',['nodo&lt; city *&gt;',['../structnodo.html',1,'']]],
  ['nodo_3c_20territoriosimulacion_20_3e',['nodo&lt; territorioSimulacion &gt;',['../structnodo.html',1,'']]],
  ['nombre',['nombre',['../structcandidate.html#ae17c411e43971f5839fc46127d76ca6b',1,'candidate::nombre()'],['../structpartid.html#a1f43ad785f7d37b2985c7ecf7c3ac1a3',1,'partid::nombre()'],['../structcity.html#a5afcdd91855565bfa486fa8be77cb1ba',1,'city::nombre()'],['../structdepartament.html#a7b041b0574bdba1835f202d6dc72e7d6',1,'departament::nombre()']]]
];
