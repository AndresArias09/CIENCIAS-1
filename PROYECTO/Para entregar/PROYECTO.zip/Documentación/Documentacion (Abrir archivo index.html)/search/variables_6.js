var searchData=
[
  ['info',['info',['../structnode.html#ae7fd8df776fdbb68ade841d55938e36a',1,'node']]],
  ['izq',['izq',['../structx.html#a00d01b034bc01ce320fdb0ccd44170c9',1,'x']]]
];
