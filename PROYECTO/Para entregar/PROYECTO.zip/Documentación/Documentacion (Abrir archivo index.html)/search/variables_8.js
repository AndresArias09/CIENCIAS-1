var searchData=
[
  ['nombre',['nombre',['../structcandidate.html#ae17c411e43971f5839fc46127d76ca6b',1,'candidate::nombre()'],['../structpartid.html#a1f43ad785f7d37b2985c7ecf7c3ac1a3',1,'partid::nombre()'],['../structcity.html#a5afcdd91855565bfa486fa8be77cb1ba',1,'city::nombre()'],['../structdepartament.html#a7b041b0574bdba1835f202d6dc72e7d6',1,'departament::nombre()']]]
];
