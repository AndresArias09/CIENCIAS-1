var searchData=
[
  ['apellido',['apellido',['../structcandidate.html#aa6f0aac397c2e0d69d59bcba53b27a02',1,'candidate']]]
];
