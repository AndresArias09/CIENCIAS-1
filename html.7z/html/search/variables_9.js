var searchData=
[
  ['sexo',['sexo',['../structcandidate.html#a9246a0984ff32e598f6da56d212b7a89',1,'candidate']]]
];
