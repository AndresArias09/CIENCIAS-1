var searchData=
[
  ['tarjetonporciudad',['tarjetonPorCiudad',['../main_8cpp.html#a4de91c65d9b3e974e538bd949f83ff45',1,'main.cpp']]],
  ['tarjetonpresidencial',['tarjetonPresidencial',['../main_8cpp.html#a6f3e08cfac903fb0cb17fafe943794c1',1,'main.cpp']]],
  ['territorio',['territorio',['../structcandidate.html#a37bd67a40bb8a04647c512290e38996f',1,'candidate']]]
];
