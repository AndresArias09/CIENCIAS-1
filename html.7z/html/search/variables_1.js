var searchData=
[
  ['candidatos',['candidatos',['../structpartid.html#a8b91709524720716d2f39919d2031f02',1,'partid::candidatos()'],['../structcity.html#a68219a3410a71a5f188d326b4d6d69fb',1,'city::candidatos()']]],
  ['cantidad',['cantidad',['../classfacade.html#abdf705c8916380e442c16610217b630c',1,'facade']]],
  ['cc',['cc',['../structcandidate.html#a3487266510bb7c8562ac700011ebd0f3',1,'candidate']]],
  ['censo',['censo',['../structcity.html#a7943c268fd53711bbcc1faeb1e907064',1,'city']]],
  ['ciudades',['ciudades',['../structdepartament.html#ab4198b741ed7fa78c5837b204b0f8da8',1,'departament']]],
  ['ciudadnatal',['ciudadNatal',['../structcandidate.html#a606266aba09a43dcccc7300f20b6300f',1,'candidate']]],
  ['ciudadresidencia',['ciudadResidencia',['../structcandidate.html#a7a40a6e9c9d805d0ae6d7acd511f8997',1,'candidate']]],
  ['clave',['clave',['../structcandidate.html#a4d7cf79824a4c9156c5413da5e857bc9',1,'candidate::clave()'],['../structpartid.html#a92af9cfe89a3fde6142560427eb26839',1,'partid::clave()'],['../structcity.html#aeade8b2da30fa4b13655371952c4a5cf',1,'city::clave()'],['../structdepartament.html#ac3a8598670ff4109ef11554c201ccd9f',1,'departament::clave()']]]
];
