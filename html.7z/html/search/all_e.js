var searchData=
[
  ['votosdepartamentosexo',['votosDepartamentoSexo',['../classdepartamento.html#a3fbf504b84d54e7a5881d52b5dbf80d5',1,'departamento']]]
];
