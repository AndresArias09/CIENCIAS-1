var searchData=
[
  ['partido',['partido',['../structcandidate.html#a851038f67ce03bb4b85023ebf36e8b17',1,'candidate']]]
];
