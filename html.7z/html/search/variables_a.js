var searchData=
[
  ['territorio',['territorio',['../structcandidate.html#a37bd67a40bb8a04647c512290e38996f',1,'candidate']]]
];
