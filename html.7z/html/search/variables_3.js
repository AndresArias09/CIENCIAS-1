var searchData=
[
  ['estado',['estado',['../structcandidate.html#ac40a37cc6f8b33f9bc3b94b800d0a02c',1,'candidate']]],
  ['estadocivil',['estadoCivil',['../structcandidate.html#a926401428597a855b5bef09101f68ae6',1,'candidate']]]
];
