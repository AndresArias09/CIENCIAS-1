var searchData=
[
  ['iniciarsimulacion',['iniciarSimulacion',['../main_8cpp.html#a84cf02df8557ff01c2c00d8b208320ef',1,'main.cpp']]],
  ['insertarcandidato',['insertarCandidato',['../classcandidato.html#a531bbd5ee1b760778832f53b74835b15',1,'candidato::insertarCandidato()'],['../main_8cpp.html#a025c300c6b48a20732da20c0b40fba4a',1,'insertarCandidato():&#160;main.cpp']]],
  ['insertarvice',['insertarVice',['../main_8cpp.html#afeb8a162ceb9cc9266b39e736bc9dd9c',1,'main.cpp']]]
];
