var indexSectionsWithContent =
{
  0: "acdefgilmnprstv",
  1: "cdfp",
  2: "cdefmp",
  3: "acegilmstv",
  4: "acdeflnprst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

