var searchData=
[
  ['departamento',['departamento',['../structcity.html#a31e2d038b0f58792ef0212a76e29a8d9',1,'city']]]
];
