var searchData=
[
  ['partido_2eh',['partido.h',['../partido_8h.html',1,'']]]
];
