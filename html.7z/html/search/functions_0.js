var searchData=
[
  ['agregarcandidato',['agregarCandidato',['../classciudad.html#a682fc9e21739d8cd58b45a33163267ed',1,'ciudad::agregarCandidato()'],['../classpartido.html#a7940945ea35bfe8a3a8b8adfb7e8fd5b',1,'partido::agregarCandidato()']]],
  ['agregarciudad',['agregarCiudad',['../classciudad.html#aa55328cc6f58ac2d863d922309639452',1,'ciudad::agregarCiudad()'],['../classdepartamento.html#af3da22ee6c3deee729c561fe8829c4a5',1,'departamento::agregarCiudad()']]],
  ['alcaldesporpartido',['alcaldesPorPartido',['../main_8cpp.html#a992a82f0a3fbcc88d28745f9e7a88dd4',1,'main.cpp']]]
];
