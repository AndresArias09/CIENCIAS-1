var searchData=
[
  ['leerregistros',['leerRegistros',['../classcandidato.html#a3327a02a7cdc7ed45b6ed01282772aa5',1,'candidato::leerRegistros()'],['../classciudad.html#a019f506df703b28097994e197d658a16',1,'ciudad::leerRegistros()'],['../classdepartamento.html#a1be3759f04abb9e8eee35cf238e1b521',1,'departamento::leerRegistros()'],['../classfacade.html#a7e64dae66cb637ecea7b04ea7f9dea24',1,'facade::leerRegistros()'],['../classpartido.html#a4125f81eca2e34239c5fc431a9bfeec6',1,'partido::leerRegistros()']]]
];
