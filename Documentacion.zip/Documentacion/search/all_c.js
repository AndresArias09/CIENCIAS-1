var searchData=
[
  ['sexo',['sexo',['../structcandidate.html#a9246a0984ff32e598f6da56d212b7a89',1,'candidate']]],
  ['simulacion',['simulacion',['../main_8cpp.html#a26a18788dc3baff7751efc5cc34345e9',1,'main.cpp']]],
  ['simulacionciudades',['simulacionCiudades',['../classsimulacion_ciudades.html',1,'']]],
  ['simulacionciudades_2eh',['simulacionCiudades.h',['../simulacion_ciudades_8h.html',1,'']]],
  ['simulacionnacionales',['simulacionNacionales',['../structsimulacion_nacionales.html',1,'']]]
];
