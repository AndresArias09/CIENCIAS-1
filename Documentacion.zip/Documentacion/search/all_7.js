var searchData=
[
  ['leerregistros',['leerRegistros',['../classfacade.html#a7e64dae66cb637ecea7b04ea7f9dea24',1,'facade']]],
  ['leido',['leido',['../classfacade.html#acd616b4738aacd951c4272c8696db7cd',1,'facade']]],
  ['liberar',['liberar',['../classcandidato.html#a102d7f813cceff933a317d082f50385e',1,'candidato::liberar()'],['../classciudad.html#a96d7c2577704d453fd5bbb7ccb195190',1,'ciudad::liberar()'],['../classdepartamento.html#a57246b59d61672a73dce0e0488f76d33',1,'departamento::liberar()'],['../classpartido.html#a14c2cfbac348fe409ee574b4115b0918',1,'partido::liberar()'],['../classsimulacion_ciudades.html#ab04ac74ef12661f720cf3bfaa01f827a',1,'simulacionCiudades::liberar()']]],
  ['limpiar',['limpiar',['../classsimulacion_ciudades.html#aca6fb6a1e8a82c285af0ca690da4354d',1,'simulacionCiudades']]]
];
