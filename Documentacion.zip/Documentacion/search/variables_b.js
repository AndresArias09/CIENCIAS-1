var searchData=
[
  ['territorio',['territorio',['../structcandidate.html#a37bd67a40bb8a04647c512290e38996f',1,'candidate']]],
  ['totalbypartido',['totalByPartido',['../structdepartamento_simulacion.html#a313e47420781d5f0f22c0fd6f78c5cc9',1,'departamentoSimulacion']]],
  ['totalciudades',['totalCiudades',['../structsimulacion_nacionales.html#a9f1126c265f2a247ee7542ccf6495d73',1,'simulacionNacionales']]],
  ['totalesbypartido',['totalesByPartido',['../structsimulacion_nacionales.html#abf812250d09a3fa42a47b63f7383b204',1,'simulacionNacionales']]],
  ['totalhombres',['totalHombres',['../structdepartamento_simulacion.html#aec4d02f0ff07daf45c53ad60bd654be0',1,'departamentoSimulacion::totalHombres()'],['../structsimulacion_nacionales.html#ad4369b85667904105c3030bbc72615ee',1,'simulacionNacionales::totalHombres()']]],
  ['totalmujeres',['totalMujeres',['../structdepartamento_simulacion.html#a261afc99e5768270e3e007f3b6a4e8f0',1,'departamentoSimulacion::totalMujeres()'],['../structsimulacion_nacionales.html#a6095a6dfa8641eb56250e49ffd2f6150',1,'simulacionNacionales::totalMujeres()']]],
  ['totalvotos',['totalVotos',['../structdepartamento_simulacion.html#acd88e3bd62a6dc1e0e2254db481b19a7',1,'departamentoSimulacion']]]
];
