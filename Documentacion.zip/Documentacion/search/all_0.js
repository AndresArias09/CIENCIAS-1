var searchData=
[
  ['abstencion',['abstencion',['../structterritorio_simulacion.html#a90bb058da34c01aead43cc4b25cdf96b',1,'territorioSimulacion::abstencion()'],['../structdepartamento_simulacion.html#a68bf75f920c598e74546c73749dbdd08',1,'departamentoSimulacion::abstencion()']]],
  ['agregarcandidato',['agregarCandidato',['../classciudad.html#a682fc9e21739d8cd58b45a33163267ed',1,'ciudad::agregarCandidato()'],['../classpartido.html#a7940945ea35bfe8a3a8b8adfb7e8fd5b',1,'partido::agregarCandidato()']]],
  ['agregarciudad',['agregarCiudad',['../classciudad.html#aa55328cc6f58ac2d863d922309639452',1,'ciudad::agregarCiudad()'],['../classdepartamento.html#af3da22ee6c3deee729c561fe8829c4a5',1,'departamento::agregarCiudad()']]],
  ['agregardepartamento',['agregarDepartamento',['../classdepartamento.html#ab8b4891d6d2c77418fa96187ccf37d89',1,'departamento']]],
  ['agregarpartido',['agregarPartido',['../classpartido.html#ac5fd34d2311355d2e09e1c04a1de4a34',1,'partido']]],
  ['alcaldesporpartido',['alcaldesPorPartido',['../main_8cpp.html#a992a82f0a3fbcc88d28745f9e7a88dd4',1,'main.cpp']]],
  ['apellido',['apellido',['../structcandidate.html#aa6f0aac397c2e0d69d59bcba53b27a02',1,'candidate']]]
];
