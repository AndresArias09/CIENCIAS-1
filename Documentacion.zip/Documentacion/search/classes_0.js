var searchData=
[
  ['candidate',['candidate',['../structcandidate.html',1,'']]],
  ['candidato',['candidato',['../classcandidato.html',1,'']]],
  ['candidatosimulacion',['candidatoSimulacion',['../structcandidato_simulacion.html',1,'']]],
  ['city',['city',['../structcity.html',1,'']]],
  ['ciudad',['ciudad',['../classciudad.html',1,'']]]
];
