var searchData=
[
  ['partid',['partid',['../structpartid.html',1,'']]],
  ['partido',['partido',['../classpartido.html',1,'']]]
];
