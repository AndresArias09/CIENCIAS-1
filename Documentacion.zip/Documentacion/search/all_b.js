var searchData=
[
  ['representante',['representante',['../structpartid.html#a3f78b34a0b4b0a2e83f586586d3471a5',1,'partid']]],
  ['rescribirarchivos',['rescribirArchivos',['../main_8cpp.html#a1d13f2fbb1cb3e9c18d709049dee413c',1,'main.cpp']]]
];
