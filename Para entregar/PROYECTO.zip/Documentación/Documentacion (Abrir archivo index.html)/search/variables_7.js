var searchData=
[
  ['leido',['leido',['../classfacade.html#acd616b4738aacd951c4272c8696db7cd',1,'facade']]]
];
