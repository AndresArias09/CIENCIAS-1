var searchData=
[
  ['partid',['partid',['../structpartid.html',1,'']]],
  ['partido',['partido',['../classpartido.html',1,'partido'],['../structcandidate.html#a851038f67ce03bb4b85023ebf36e8b17',1,'candidate::partido()']]],
  ['partido_2eh',['partido.h',['../partido_8h.html',1,'']]],
  ['pila',['Pila',['../class_pila.html',1,'Pila&lt; T &gt;'],['../class_pila.html#abc664d86f121a855c62018a7450e47ed',1,'Pila::Pila()']]],
  ['pila_2eh',['Pila.h',['../_pila_8h.html',1,'']]],
  ['porcentaje',['porcentaje',['../structcandidato_simulacion.html#a6cd18e3ca3771931ea1f5e3c232e615e',1,'candidatoSimulacion']]]
];
