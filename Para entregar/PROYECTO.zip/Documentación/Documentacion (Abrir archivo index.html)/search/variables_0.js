var searchData=
[
  ['abstencion',['abstencion',['../structterritorio_simulacion.html#a90bb058da34c01aead43cc4b25cdf96b',1,'territorioSimulacion::abstencion()'],['../structdepartamento_simulacion.html#a68bf75f920c598e74546c73749dbdd08',1,'departamentoSimulacion::abstencion()']]],
  ['apellido',['apellido',['../structcandidate.html#aa6f0aac397c2e0d69d59bcba53b27a02',1,'candidate']]]
];
