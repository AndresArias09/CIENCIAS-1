var searchData=
[
  ['lista',['Lista',['../class_lista.html',1,'']]],
  ['lista_3c_20candidate_20_2a_3e',['Lista&lt; candidate *&gt;',['../class_lista.html',1,'']]],
  ['lista_3c_20city_20_2a_3e',['Lista&lt; city *&gt;',['../class_lista.html',1,'']]],
  ['lista_3c_20territoriosimulacion_20_3e',['Lista&lt; territorioSimulacion &gt;',['../class_lista.html',1,'']]],
  ['listao',['ListaO',['../class_lista_o.html',1,'']]],
  ['listao_3c_20candidatosimulacion_20_3e',['ListaO&lt; candidatoSimulacion &gt;',['../class_lista_o.html',1,'']]]
];
