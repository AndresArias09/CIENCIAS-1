var searchData=
[
  ['partido_2eh',['partido.h',['../partido_8h.html',1,'']]],
  ['pila_2eh',['Pila.h',['../_pila_8h.html',1,'']]]
];
