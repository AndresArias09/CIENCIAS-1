var searchData=
[
  ['facade',['facade',['../classfacade.html',1,'']]],
  ['facade_2eh',['facade.h',['../facade_8h.html',1,'']]],
  ['fechanacimiento',['fechaNacimiento',['../structcandidate.html#a7bf460e1f88209d3b1ae82f41204b7cc',1,'candidate']]],
  ['formulavi',['formulaVi',['../structcandidate.html#adbc9833cf1af8d33dc1e5d45b99e5c1d',1,'candidate']]]
];
