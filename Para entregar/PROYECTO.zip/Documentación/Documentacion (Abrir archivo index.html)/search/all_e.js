var searchData=
[
  ['vacia',['vacia',['../class_pila.html#a8422abd8aa4d73d13d1b7dfad8244bfd',1,'Pila']]],
  ['votos',['votos',['../structcandidato_simulacion.html#a388e3b8b9766b867104dd1a8128f140c',1,'candidatoSimulacion']]],
  ['votosblanco',['votosBlanco',['../structterritorio_simulacion.html#ad58275a43a55937391e2be43d5694111',1,'territorioSimulacion::votosBlanco()'],['../structdepartamento_simulacion.html#a1f1b45841fb4e0fe2f0aa154ce907a3f',1,'departamentoSimulacion::votosBlanco()']]],
  ['votosdepartamentosexo',['votosDepartamentoSexo',['../classdepartamento.html#a3fbf504b84d54e7a5881d52b5dbf80d5',1,'departamento']]],
  ['votosnulos',['votosNulos',['../structterritorio_simulacion.html#a124ef697ee4c55fdb08381e458d4931c',1,'territorioSimulacion::votosNulos()'],['../structdepartamento_simulacion.html#aa5ed86ce9ef07c304316ea0599115e2e',1,'departamentoSimulacion::votosNulos()']]]
];
