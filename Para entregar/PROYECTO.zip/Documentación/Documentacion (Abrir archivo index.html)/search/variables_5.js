var searchData=
[
  ['ganador',['ganador',['../structterritorio_simulacion.html#a13861b3eea16da42de3f99163645a2e1',1,'territorioSimulacion']]]
];
