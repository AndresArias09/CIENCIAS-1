var searchData=
[
  ['elemento',['elemento',['../structx.html#ad68b8637a83f5c430a87d0acc6e0e812',1,'x']]],
  ['estado',['estado',['../structcandidate.html#ac40a37cc6f8b33f9bc3b94b800d0a02c',1,'candidate::estado()'],['../structpartid.html#a1259b6dd560561b434b9ffc18a13205f',1,'partid::estado()'],['../structcity.html#aced75a1fb3bad1e71c5619091332a941',1,'city::estado()']]],
  ['estadocivil',['estadoCivil',['../structcandidate.html#a926401428597a855b5bef09101f68ae6',1,'candidate']]]
];
