var searchData=
[
  ['representante',['representante',['../structpartid.html#a3f78b34a0b4b0a2e83f586586d3471a5',1,'partid']]]
];
