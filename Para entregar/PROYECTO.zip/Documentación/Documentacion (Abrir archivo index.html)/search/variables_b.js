var searchData=
[
  ['sexo',['sexo',['../structcandidate.html#a9246a0984ff32e598f6da56d212b7a89',1,'candidate']]],
  ['sig',['sig',['../structnodo.html#add3a68f9ec1125a7ac8cc52693a3ab8c',1,'nodo::sig()'],['../structnode.html#ad409f80a1170f2f099b07cb7e2f4c8e4',1,'node::sig()']]]
];
