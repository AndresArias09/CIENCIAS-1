var searchData=
[
  ['x',['x',['../structnodo.html#a9a4014ae283f98117408f0340a753979',1,'nodo']]]
];
